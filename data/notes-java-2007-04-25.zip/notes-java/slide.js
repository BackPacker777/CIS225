function footer() {
    document.write("<div class='footer'>");
    document.write("</div>");
}
    
function footer(prev, next) {
    document.write("<div class='footer'><table border='0' width='100%'><tr>");
    if (prev == null) {
        document.write("<td align='left'><s>Prev</s></td>");
    } else {
        document.write("<td align='left'><a href='" + prev + "'>Prev</a></td>");
    }
    document.write("<td><a href='index.html'>Index</a></td>");
    if (next == null) {
        document.write("<td align='right'><s>Next</s></td>");
    } else {
        document.write("<td align='right'><a href='" + next + "'>Next</a></td>");
    }
    document.write("</tr></table><�</div>");
}//endfunction

function setActiveStyleSheet(title) {
    var i, a;
    for (i=0; (a = document.getElementsByTagName("link")[i]); i++) {
        if (a.getAttribute("rel") &&
                a.getAttribute("rel").indexOf("style") != -1 &&
                a.getAttribute("title")) {
            a.disabled = (a.getAttribute("title") != title);
        }
    }
}
